# Save old config files:
if [ ! -L etc/X11/kdm ]; then
  if [ -d etc/X11/kdm ]; then
    mkdir -p etc/kde/kdm
    cp -a etc/X11/kdm/* etc/opt/kde/kdm
    rm -rf etc/X11/kdm
    ( cd etc/X11 ; ln -sf /etc/opt/kde/kdm kdm )
  fi
elif [ ! -e etc/X11/kdm ]; then
  mkdir -p etc/X11
  ( cd etc/X11 ; ln -sf /etc/opt/kde/kdm kdm )
fi

#!/bin/sh
config() {
  NEW="$1"
  OLD="`dirname $NEW`/`basename $NEW .new`"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "`cat $OLD | md5sum`" = "`cat $NEW | md5sum`" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}
config etc/opt/kde/kdm/kdmrc.new
config etc/opt/kde/kdm/backgroundrc.new

